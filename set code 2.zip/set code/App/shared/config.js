﻿(function() {
    angular.module("app.addons", ["ngSanitize"]);



})()