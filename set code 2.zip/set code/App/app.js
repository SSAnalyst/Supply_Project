﻿(function () {

    angular.module("app",
        [
            'vs-repeat',
            'ui.router',
            'app.addons',
            "ngAnimate",
            "ngFileUpload",
            "ui.bootstrap",
            "ngSanitize"
        ]);

})()