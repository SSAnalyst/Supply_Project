﻿(function() {
    angular.module("app")
        .component("admin.picker",
        {
            template: "<h2 class='centered'>Admin</h2>",
            controller: [Controller]
        });

    function Controller(){}

})()